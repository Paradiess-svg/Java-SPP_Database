/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ukk_spp;

/**
 *
 * @author izzan
 */
public class petugas {
         int id_petugas;
    String username, nama_petugas;

    public petugas(int id_petugas, String username, String nama_petugas) {
        this.id_petugas = id_petugas;
        this.id_petugas = id_petugas;
        this.nama_petugas = nama_petugas;
    }

    public int getIdPetugas() {
        return id_petugas;
    }
    
    public String getUsernamePetugas() {
        return username;
    }

    public String getNamaPetugas() {
        return nama_petugas;
    }
    
}

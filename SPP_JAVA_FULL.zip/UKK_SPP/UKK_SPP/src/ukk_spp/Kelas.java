/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ukk_spp;

/**
 *
 * @author Lenovo
 */
public class Kelas {
    int id_kelas;
    String nama_kelas, kompetensi_keahlian;

    public Kelas(int id_kelas, String nama_kelas, String kompetensi_keahlian) {
        this.id_kelas = id_kelas;
        this.nama_kelas = nama_kelas;
        this.kompetensi_keahlian = kompetensi_keahlian;
    }

    public int getId_Kelas() {
        return id_kelas;
    }

    public String getNamaKelas() {
        return nama_kelas;
    }

    public String getKompetensiKeahlian() {
        return kompetensi_keahlian;
    }
}

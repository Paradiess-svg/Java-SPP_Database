/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ukk_spp;

/**
 *
 * @author Lenovo
 */
public class classSPP {
    int id_spp, nominal;
    String tahun;

    public classSPP(int id_spp, String tahun, int nominal) {
        this.id_spp = id_spp;
        this.tahun = tahun;
        this.nominal = nominal;
    }

    public int getId_SPP() {
        return id_spp;
    }

    public String getTahun() {
        return tahun;
    }

    public int getNominal() {
        return nominal;
    }
}

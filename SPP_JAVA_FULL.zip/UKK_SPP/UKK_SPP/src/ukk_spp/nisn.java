/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ukk_spp;

/**
 *
 * @author izzan
 */
public class nisn {
    int nisn;
    String nama;

    public nisn(int nisn, String nama) {
        this.nisn = nisn;
        this.nama = nama;
    }

    public int getNisn() {
        return nisn;
    }

    public String getNamaSiswa() {
        return nama;
    }
}
